import 'package:flutter/material.dart';
import 'package:metrik_viewer_x/viewerapp/app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(ViewerApp());
}
