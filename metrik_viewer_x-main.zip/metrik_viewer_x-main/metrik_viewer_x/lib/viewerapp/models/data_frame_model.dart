import 'data_row_model.dart';

class DataFrameModel {
  final List<DataRowModel> rows;

  DataFrameModel({required this.rows});
}
