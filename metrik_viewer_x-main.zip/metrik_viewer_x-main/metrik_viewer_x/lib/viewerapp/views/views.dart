export 'main_view.dart';
export 'detail_view.dart';
