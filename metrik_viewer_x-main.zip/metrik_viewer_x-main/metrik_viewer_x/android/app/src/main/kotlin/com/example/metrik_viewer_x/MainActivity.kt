package com.example.metrik_viewer_x

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
